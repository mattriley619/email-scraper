import java.util.Vector;

public class ExtractedData
{
    String link;
    int distance;
    String baseDomain;
    ListOfEmails emailList;
    int tag;

    ExtractedData()
    {
        emailList = new ListOfEmails();

    }

    @Override
    public String toString()
    {
        return "A";
    }







}
