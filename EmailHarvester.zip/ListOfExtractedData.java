import javax.swing.*;

public class ListOfExtractedData extends DefaultListModel<ExtractedData>
{

    ListOfExtractedData()
    {

    }


    void addExtractedData()
    {



    }


}
